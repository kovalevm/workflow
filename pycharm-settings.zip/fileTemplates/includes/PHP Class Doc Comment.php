/**
 * Class ${NAME}
 *
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @author Mikhail Kovalev <mikhail.kovalev@orbitsoft.com>
 *
 */
